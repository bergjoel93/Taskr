import projectManager from "../manage/ProjectManager";
/** 
 * responsible for creating html for when the user clicks on 'All Tasks' button. 
 */

function createAllTasksPage(){
    // 
}